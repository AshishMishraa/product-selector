<?php
   /*
   Plugin Name: Product Selector
   Plugin URI: https://iphtechnologies.com/
   description:  Product Selector is a plugin to select specific product by questionnaireand snding email 
   Version: 1.2
   Author: Ashish Kumar Mishra
   Author https://iphtechnologies.com/
   License: GPL2
   */
?>
<?php
include "ps-functions.php";
class Productelector {

    /**
     * A reference to an instance of this class.
     */
    private static $instance;

    /**
     * The array of templates that this plugin tracks.
     */
    protected $templates;

    /**
     * Returns an instance of this class.
     */
    public static function get_instance() {

        if ( null == self::$instance ) {
            self::$instance = new Productelector();
        }

        return self::$instance;

    }

    /**
     * Initializes the plugin by setting filters and administration functions.
     */
    private function __construct() {

        $this->templates = array();


        // Add a filter to the attributes metabox to inject template into the cache.
        if ( version_compare( floatval( get_bloginfo( 'version' ) ), '4.7', '<' ) ) {

            // 4.6 and older
            add_filter(
                'page_attributes_dropdown_pages_args',
                array( $this, 'register_project_templates' )
            );

        } else {

            // Add a filter to the wp 4.7 version attributes metabox
            add_filter(
                'theme_page_templates', array( $this, 'add_new_template' )
            );

        }

        // Add a filter to the save post to inject out template into the page cache
        add_filter(
            'wp_insert_post_data',
            array( $this, 'register_project_templates' )
        );


        // Add a filter to the template include to determine if the page has our
        // template assigned and return it's path
        add_filter(
            'template_include',
            array( $this, 'view_project_template')
        );


        // Add your templates to this array.
        $this->templates = array(
            'product-selector-template.php' => 'Product Selector',
        );

    }

    /**
     * Adds our template to the page dropdown for v4.7+
     *
     */
    public function add_new_template( $posts_templates ) {
        $posts_templates = array_merge( $posts_templates, $this->templates );
        return $posts_templates;
    }

    /**
     * Adds our template to the pages cache in order to trick WordPress
     * into thinking the template file exists where it doens't really exist.
     */
    public function register_project_templates( $atts ) {

        // Create the key used for the themes cache
        $cache_key = 'page_templates-' . md5( get_theme_root() . '/' . get_stylesheet() );

        // Retrieve the cache list.
        // If it doesn't exist, or it's empty prepare an array
        $templates = wp_get_theme()->get_page_templates();
        if ( empty( $templates ) ) {
            $templates = array();
        }

        // New cache, therefore remove the old one
        wp_cache_delete( $cache_key , 'themes');

        // Now add our template to the list of templates by merging our templates
        // with the existing templates array from the cache.
        $templates = array_merge( $templates, $this->templates );

        // Add the modified cache to allow WordPress to pick it up for listing
        // available templates
        wp_cache_add( $cache_key, $templates, 'themes', 1800 );

        return $atts;

    }

    /**
     * Checks if the template is assigned to the page
     */
    public function view_project_template( $template ) {
        // Return the search template if we're searching (instead of the template for the first result)
        if ( is_search() ) {
            return $template;
        }

        // Get global post
        global $post;

        // Return template if post is empty
        if ( ! $post ) {
            return $template;
        }

        // Return default template if we don't have a custom one defined
        if ( ! isset( $this->templates[get_post_meta(
            $post->ID, '_wp_page_template', true
        )] ) ) {
            return $template;
        }

        // Allows filtering of file path
        $filepath = apply_filters( 'page_templater_plugin_dir_path', plugin_dir_path( __FILE__ ) );

        $file =  $filepath . get_post_meta(
            $post->ID, '_wp_page_template', true
        );

        // Just to be safe, we check if the file exist first
        if ( file_exists( $file ) ) {
            return $file;
        } else {
            echo $file;
        }

        // Return template
        return $template;

    }

}
add_action( 'plugins_loaded', array( 'Productelector', 'get_instance' ) );
add_action( 'wp_ajax_send_product_selected_email', 'send_product_selected_email' );
add_action( 'wp_ajax_nopriv_send_product_selected_email', 'send_product_selected_email' );


function send_product_selected_email(){
    
        $pain_type= ucfirst(implode(" ",explode("-",$_REQUEST['pain_type'])));
        $pain_intensity= ucfirst(implode(" ",explode("-",$_REQUEST['pain_intensity'])));
        $inflammation= ucfirst(implode(" ",explode("-",$_REQUEST['inflammation'])));
        $name=$_REQUEST['name'];

      $pain_type=$_REQUEST['pain_type'];
      $inflammation=$_REQUEST['inflammation'];
    
     $moderate=array();
     $strong=array();
     $intense=array();
     global $wpdb;
     $results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}product_selector WHERE pain_type = '".$_REQUEST['pain_type']."'   AND inflammation = '".$_REQUEST['inflammation']."'", OBJECT );
     
    foreach($results as $res){
         if($res->pain_intensity == 'moderate'){
             $data=array();
                    $pid=  $res->product_id;
                    $product = wc_get_product($pid );
                    $the_content=   get_the_excerpt( $pid );
                    $shortcode_tags = array('VC_COLUMN_INNTER');
                    $values = array_values( $shortcode_tags );
                    $exclude_codes  = implode( '|', $values );
                    $data['the_content'] = preg_replace( "~(?:\[/?)(?!(?:$exclude_codes))[^/\]]+/?\]~s", '', $the_content );
                    $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $pid  ), 'single-post-thumbnail' );
                    $data['image_url']= $image_url[0];
                    $data['title']=$product->get_title();
                    $data['url']=get_permalink( $pid);
             $moderate=$data;
             
         }

         if($res->pain_intensity == 'strong'){
                  $data=array();
                    $pid=  $res->product_id;
                    $product = wc_get_product($pid);
                    $the_content=  get_the_excerpt( $pid );
                    $shortcode_tags = array('VC_COLUMN_INNTER');
                    $values = array_values( $shortcode_tags );
                    $exclude_codes  = implode( '|', $values );
                    $data['the_content'] = preg_replace( "~(?:\[/?)(?!(?:$exclude_codes))[^/\]]+/?\]~s", '', $the_content );
                    $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $pid  ), 'single-post-thumbnail' );
                    $data['image_url']= $image_url[0];
                    $data['title']=$product->get_title();
                    $data['url']=get_permalink( $pid);
             $strong=$data;
         }

         if($res->pain_intensity == 'intense'){
                      $data=array();
                    $pid=  $res->product_id;
                    $product = wc_get_product($pid);
                    $the_content=   get_the_excerpt( $pid );
                    $shortcode_tags = array('VC_COLUMN_INNTER');
                    $values = array_values( $shortcode_tags );
                    $exclude_codes  = implode( '|', $values );
                    $data['the_content'] = preg_replace( "~(?:\[/?)(?!(?:$exclude_codes))[^/\]]+/?\]~s", '', $the_content );
                    $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $pid  ), 'single-post-thumbnail' );
                    $data['image_url']= $image_url[0];
                    $data['title']=$product->get_title();
                    $data['url']=get_permalink( $pid);
             $intense=$data;
         }
        
     }
    
  
  $content=     psemailTemplate($name, $moderate,$strong,$intense);
    
    
    
    
    $headers[] = 'From: Deep Heat <info@deepheat.com.au>';
        $headers[] = 'Content-Type: text/html; charset=UTF-8';
mailChimpSubscription($name,$_REQUEST['email'],$LNAME=' '); 
if(wp_mail( $_REQUEST['email'], 'Deep Heat Product Selection', $content, $headers )) { ?>
    
    <div class="col-md-12" style="padding:40px; background:red;">
        <center>
        <h2 style="color:white"> Thanks for sharing your pain with us , Please check your email , to get your appropriate product</h2><br><br>
            <a href="<?php echo site_url();?>"  style="background:white; padding:10px" >Go Home</a>
        
        </center>   
    </div>
    
    
    <?php }

    die();
}




function   mailChimpSubscription($FNAME,$EMAIL, $LNAME=''){   

    if(!empty($EMAIL) && !filter_var($EMAIL, FILTER_VALIDATE_EMAIL) === false){ 

        // MailChimp API credentials 

        $apiKey = '8b65670b6c388af950bca7da72fc36ce-us10'; 

        $listID = '85d1f29969'; 

         

        // MailChimp API URL 

        $memberID = md5(strtolower($EMAIL)); 

        $dataCenter = substr($apiKey,strpos($apiKey,'-')+1); 

        $url = 'https://' . $dataCenter . '.api.mailchimp.com/3.0/lists/' . $listID . '/members/' . $memberID; 

         

        // member information 

        $json = json_encode([ 

            'email_address' => $EMAIL, 

            'status'        => 'subscribed', 

            'merge_fields'  => [ 

                'FNAME'     => $FNAME, 

                'LNAME'     => $LNAME, 

                'EMAIL'=>$EMAIL 

            ] 

        ]); 

         

        // send a HTTP POST request with curl 

        $ch = curl_init($url); 

        curl_setopt($ch, CURLOPT_USERPWD, 'user:' . $apiKey); 

        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']); 

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 

        curl_setopt($ch, CURLOPT_TIMEOUT, 10); 

        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT'); 

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 

        curl_setopt($ch, CURLOPT_POSTFIELDS, $json); 

        $result = curl_exec($ch); 

        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE); 

        curl_close($ch); 

         

        // store the status message based on response code 

        if ($httpCode == 200) { 

           // echo'<p style="color: #34A853">You have successfully subscribed to CodexWorld.</p>'; 

        } else {/* 

            switch ($httpCode) { 

                case 214: 

                    $msg = 'You are already subscribed.'; 

                    break; 

                default: 

                    $msg = 'Some problem occurred, please try again.'; 

                    break; 

            } 

            echo  '<p style="color: #EA4335">'.$msg.'</p>'; 

        */} 

    }else{ 

       // echo '<p style="color: #EA4335">Please enter valid email address.</p>'; 

    } 

} 
















add_action( 'wp_ajax_load_product_selected', 'load_product_selected' );
add_action( 'wp_ajax_nopriv_load_product_selected', 'load_product_selected' );

function load_product_selected(){
global $wpdb;
$results = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}product_selector WHERE pain_type = '".$_REQUEST['pain_type']."'  AND pain_intensity = '".$_REQUEST['pain_intensity']."'  AND inflammation = '".$_REQUEST['inflammation']."'", OBJECT );
$productId= isset($results->product_id)?$results->product_id:'';
if($productId !=''){
$product = wc_get_product( $productId );
$excrept=get_the_excerpt( $productId );

    
    $the_content=   $product->description;
    $shortcode_tags = array('VC_COLUMN_INNTER');
    $values = array_values( $shortcode_tags );
    $exclude_codes  = implode( '|', $values );
    $the_content = preg_replace( "~(?:\[/?)(?!(?:$exclude_codes))[^/\]]+/?\]~s", '', $the_content );
    $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $productId ), 'single-post-thumbnail' );
    $image_url= $image_url[0];

    ?>
    <div class="col-md-6"><h2><?php echo $product->get_title(); ?></h2><br><a href="<?php echo get_permalink( $productId ); ?>"><img src="<?php echo  $image_url; ?>" ></a> <br><br><h2> <center><?php echo $product->get_price_html(); ?></center> </div>
    <div class="col-md-6"><br><br><?php echo $excrept; ?><br></div>
        <input type="hidden" value="<?php echo $_REQUEST['pain_type']; ?>" id="ps-pain_type">
        <input type="hidden" value="<?php echo $_REQUEST['pain_intensity']; ?>" id="ps-pain_intensity">
        <input type="hidden" value="<?php echo  $_REQUEST['inflammation']; ?>" id="ps-inflammation">
        <input type="hidden" value="<?php echo  $productId; ?>" id="ps-product_id">
    <?php
}

die();

}


add_action( 'wp_footer', 'productelectorscript' );
function productelectorscript(){
  ?>
  <script>

jQuery("input[name='pain_type']").on('click',function(){ loadSelectedProduct();  })
jQuery("input[name='pain_intensity']").on('click',function(){ loadSelectedProduct(); })
jQuery("input[name='inflammation']").on('click',function(){ loadSelectedProduct();  })

function loadSelectedProduct(){
    var pain_type=  jQuery("input[name='pain_type']:checked"). val();
    var pain_intensity=  jQuery("input[name='pain_intensity']:checked"). val();
    var inflammation=  jQuery("input[name='inflammation']:checked"). val();
     if(pain_type !='' && pain_intensity !='' && inflammation !='' && typeof pain_type !='undefined' && typeof pain_intensity !='undefined' && typeof inflammation !='undefined' ){
        var data = {
            'action': 'load_product_selected',
            'pain_type': pain_type,
            'pain_intensity': pain_intensity,
            'inflammation': inflammation,
        };
         jQuery('.result-product').show();
        jQuery('.result-product').html('<center><img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . 'product-selector/images/loader.gif'; ?>"></center>') ;
         
        jQuery.post('<?php echo admin_url('admin-ajax.php'); ?>', data, function(response) {
             jQuery('.result-product').html( response)  ; 
        });
     }
}

 </script>
  <?php
}
